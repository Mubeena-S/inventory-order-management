package com.mubeena.inventory.controller;

import com.mubeena.inventory.entity.Order;
import com.mubeena.inventory.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired private OrderService orderService;

    @PostMapping
    public String placeOrder(Authentication auth) {
        return orderService.placeOrder(auth.getName());
    }

    @GetMapping("/my")
    public List<Order> myOrders(Authentication auth) {
        return orderService.getUserOrders(auth.getName());
    }

    @GetMapping
    public List<Order> allOrders() {
        return orderService.getAllOrders();
    }
}
