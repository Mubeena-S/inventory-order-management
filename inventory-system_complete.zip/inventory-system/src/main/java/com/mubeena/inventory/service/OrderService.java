package com.mubeena.inventory.service;

import com.mubeena.inventory.entity.*;
import com.mubeena.inventory.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@Service
public class OrderService {

    @Autowired private UserRepository userRepo;
    @Autowired private OrderRepository orderRepo;
    @Autowired private ItemRepository itemRepo;

    public String placeOrder(String username) {
        User user = userRepo.findByUsername(username).orElseThrow();
        List<Item> items = itemRepo.findAll();

        double total = items.stream().mapToDouble(i -> i.getPrice() * 1).sum();

        OrderItem orderItem = OrderItem.builder()
                .itemId(items.get(0).getId())
                .quantity(1)
                .build();

        Order order = Order.builder()
                .user(user)
                .items(Collections.singletonList(orderItem))
                .totalPrice(total)
                .timestamp(LocalDateTime.now())
                .build();

        orderRepo.save(order);
        return "Order placed successfully";
    }

    public List<Order> getUserOrders(String username) {
        User user = userRepo.findByUsername(username).orElseThrow();
        return orderRepo.findByUser(user);
    }

    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }
}
