package com.mubeena.inventory.dto;

import lombok.*;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class AuthRequest {
    private String username;
    private String password;
    private String role; // "ADMIN" or "CUSTOMER"
}
