# Inventory and Order Management System

## Features
- Admin and Customer roles with JWT auth
- Admin: manage items, view orders
- Customer: view items, place orders, view my orders
- H2 Database for testing
- BCrypt password encryption
- Role-based access

## Technologies Used
- Java 17, Spring Boot 3, Spring Security, Spring Data JPA
- JWT, H2, Maven

## Run the App
```
mvn spring-boot:run
```
Visit H2 console at `/h2-console`.

## Sample Endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/items` (Customer)
- `POST /api/orders` (Customer)
- `GET /api/orders/my` (Customer)
- `GET /api/orders` (Admin)
- `POST/PUT/DELETE /api/items` (Admin)
